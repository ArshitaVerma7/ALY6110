```python
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
import statsmodels.api as sm
from scipy import stats
from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn import metrics

pd.set_option('display.max_rows', 10)

import warnings
warnings.filterwarnings("ignore")
```


```python
df = pd.read_csv("wine.csv")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>fixed.acidity</th>
      <th>volatile.acidity</th>
      <th>citric.acid</th>
      <th>residual.sugar</th>
      <th>chlorides</th>
      <th>free.sulfur.dioxide</th>
      <th>total.sulfur.dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>wine</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
      <td>white</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
      <td>white</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (6494, 14)




```python
pd.set_option('display.max_rows', None)
df.dtypes
```




    Unnamed: 0                int64
    fixed.acidity           float64
    volatile.acidity        float64
    citric.acid             float64
    residual.sugar          float64
    chlorides               float64
    free.sulfur.dioxide     float64
    total.sulfur.dioxide    float64
    density                 float64
    pH                      float64
    sulphates               float64
    alcohol                 float64
    quality                   int64
    wine                     object
    dtype: object




```python
df.isnull().sum()
```




    Unnamed: 0              0
    fixed.acidity           0
    volatile.acidity        0
    citric.acid             0
    residual.sugar          0
    chlorides               0
    free.sulfur.dioxide     0
    total.sulfur.dioxide    0
    density                 0
    pH                      0
    sulphates               0
    alcohol                 0
    quality                 0
    wine                    0
    dtype: int64




```python
df.duplicated().sum()
```




    0




```python
df.columns
```




    Index(['Unnamed: 0', 'fixed.acidity', 'volatile.acidity', 'citric.acid',
           'residual.sugar', 'chlorides', 'free.sulfur.dioxide',
           'total.sulfur.dioxide', 'density', 'pH', 'sulphates', 'alcohol',
           'quality', 'wine'],
          dtype='object')




```python
df["wine"].unique()
```




    array(['white', 'red'], dtype=object)




```python
from sklearn.preprocessing import OneHotEncoder
def OneHotEncoding(df, enc, categories):  
  transformed = pd.DataFrame(enc.transform(df[categories]).toarray(), columns=enc.get_feature_names_out(categories))
  return pd.concat([df.reset_index(drop=True), transformed], axis=1).drop(categories, axis=1)

categories = ["wine"]
enc_ohe = OneHotEncoder()
enc_ohe.fit(df[categories])

df = OneHotEncoding(df, enc_ohe, categories)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>fixed.acidity</th>
      <th>volatile.acidity</th>
      <th>citric.acid</th>
      <th>residual.sugar</th>
      <th>chlorides</th>
      <th>free.sulfur.dioxide</th>
      <th>total.sulfur.dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>wine_red</th>
      <th>wine_white</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>



x = df.drop(['Unnamed: 0','wine_red','wine_white'], axis =1)
y = df[['wine_red','wine_white']]


```python
x = df.drop(['Unnamed: 0','wine'], axis =1)
y = df[['wine']]
```


```python
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2)
```


```python
k_range = list(range(1,11))
train_acc = []
test_acc = []
for i in k_range:
    knn = KNeighborsClassifier(n_neighbors=i).fit(x_train,y_train)
    y_pred = knn.predict(x_test)
    y_t_pred = knn.predict(x_train)
    train_acc.append(metrics.accuracy_score(y_train, y_t_pred))
    test_acc.append(metrics.accuracy_score(y_test, y_pred))
print(train_acc)
print(test_acc)
print(max(test_acc))
```

    [0.9996150144369587, 0.9497593840230991, 0.9713185755534167, 0.9449470644850818, 0.9591915303176131, 0.9412897016361886, 0.9514918190567854, 0.9403272377285852, 0.9497593840230991, 0.9430221366698749]
    [0.9438029253271748, 0.8876058506543495, 0.9314857582755967, 0.9107005388760585, 0.9384141647421094, 0.9245573518090839, 0.930715935334873, 0.9230177059276367, 0.9376443418013857, 0.9284064665127021]
    0.9438029253271748
    


```python
print('Model accuracy score: {0:0.4f}'. format(accuracy_score(y_test, y_pred)))
```

    Model accuracy score: 0.9284
    


```python
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
               0       0.93      0.82      0.87       330
               1       0.95      0.96      0.96       969
    
       micro avg       0.94      0.93      0.94      1299
       macro avg       0.94      0.89      0.91      1299
    weighted avg       0.94      0.93      0.93      1299
     samples avg       0.93      0.93      0.93      1299
    
    


```python
from sklearn.model_selection import GridSearchCV
```


```python
##Decision Tree Model

treemodel = DecisionTreeClassifier(max_depth = 3)
treemodel.fit(x_train, y_train)
```




    DecisionTreeClassifier(max_depth=3)




```python
##HyperParameter Tuning

params = {
    'max_depth': [2, 3, 5, 10, 20],
    'min_samples_leaf': [5, 10, 20, 50, 100],
    'criterion': ["gini", "entropy"]
}
```


```python
grid_search = GridSearchCV(estimator=treemodel, 
                           param_grid=params, 
                           cv=4, n_jobs=-1, verbose=1, scoring = "recall")
grid_search.fit(x_train, y_train)
```

    Fitting 4 folds for each of 50 candidates, totalling 200 fits
    




    GridSearchCV(cv=4, estimator=DecisionTreeClassifier(max_depth=3), n_jobs=-1,
                 param_grid={'criterion': ['gini', 'entropy'],
                             'max_depth': [2, 3, 5, 10, 20],
                             'min_samples_leaf': [5, 10, 20, 50, 100]},
                 scoring='recall', verbose=1)




```python
plt.figure(figsize=(25,10))
plot = tree.plot_tree(treemodel, feature_names = x.columns.values.tolist(), class_names = ['0','1'], filled = True, fontsize = 14)
```


    
![png](output_19_0.png)
    



```python
model = treemodel.fit(x_train, y_train)
y_pred = model.predict(x_test)
print("accuracy", metrics.accuracy_score(y_test, y_pred))
```

    accuracy 0.9630484988452656
    


```python
dt_best = grid_search.best_estimator_
dt_best
```




    DecisionTreeClassifier(max_depth=2, min_samples_leaf=5)




```python
y_pred = grid_search.predict(x_test)
print("accuracy", metrics.accuracy_score(y_test, y_pred))
```

    accuracy 0.9568899153194765
    


```python
print('Model accuracy score: {0:0.4f}'. format(accuracy_score(y_test, y_pred)))
```

    Model accuracy score: 0.9569
    


```python
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
               0       0.88      0.96      0.92       316
               1       0.99      0.96      0.97       983
    
       micro avg       0.96      0.96      0.96      1299
       macro avg       0.93      0.96      0.94      1299
    weighted avg       0.96      0.96      0.96      1299
     samples avg       0.96      0.96      0.96      1299
    
    


```python
##Random Forest Model

rfclass = RandomForestClassifier(n_estimators= 20, random_state = 0)
rfclass.fit(x_train, y_train)
rfypred = rfclass.predict(x_test)
```


```python
##HyperParameter Tuning

params = {
    'max_depth': [2, 3, 5, 10, 20],
    'min_samples_leaf': [5, 10, 20, 50, 100],
    'criterion': ["gini", "entropy"]
}
```


```python
grid_search = GridSearchCV(estimator=rfclass, 
                           param_grid=params, 
                           cv=4, n_jobs=-1, verbose=1, scoring = "recall")
grid_search.fit(x_train, y_train)
```

    Fitting 4 folds for each of 50 candidates, totalling 200 fits
    




    GridSearchCV(cv=4,
                 estimator=RandomForestClassifier(n_estimators=20, random_state=0),
                 n_jobs=-1,
                 param_grid={'criterion': ['gini', 'entropy'],
                             'max_depth': [2, 3, 5, 10, 20],
                             'min_samples_leaf': [5, 10, 20, 50, 100]},
                 scoring='recall', verbose=1)




```python
dt_best = grid_search.best_estimator_
dt_best
```




    RandomForestClassifier(max_depth=2, min_samples_leaf=5, n_estimators=20,
                           random_state=0)




```python
y_pred = grid_search.predict(x_test)
print("accuracy", metrics.accuracy_score(y_test, y_pred))
```

    accuracy 0.9799846035411856
    


```python
print('Model accuracy score: {0:0.4f}'. format(accuracy_score(y_test, y_pred)))
```

    Model accuracy score: 0.9800
    


```python
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
               0       0.93      0.82      0.87       330
               1       0.95      0.96      0.96       969
    
       micro avg       0.94      0.93      0.94      1299
       macro avg       0.94      0.89      0.91      1299
    weighted avg       0.94      0.93      0.93      1299
     samples avg       0.93      0.93      0.93      1299
    
    


```python
##GradientBoosting Model

gbclass = GradientBoostingClassifier(n_estimators = 20, random_state = None)
gbclass.fit(x_train, y_train)
gbypred = gbclass.predict(x_test)
```


```python
##HyperParameter Tuning

params = {
    'max_depth': [2, 3, 5, 10, 20],
    'min_samples_leaf': [5, 10, 20, 50, 100]
}
```


```python
grid_search = GridSearchCV(estimator=gbclass, 
                           param_grid=params, 
                           cv=4, n_jobs=-1, verbose=1, scoring = "recall")
```


```python
grid_search.fit(x_train, y_train)
```

    Fitting 4 folds for each of 25 candidates, totalling 100 fits
    




    GridSearchCV(cv=4, estimator=GradientBoostingClassifier(n_estimators=20),
                 n_jobs=-1,
                 param_grid={'max_depth': [2, 3, 5, 10, 20],
                             'min_samples_leaf': [5, 10, 20, 50, 100]},
                 scoring='recall', verbose=1)




```python
dt_best = grid_search.best_estimator_
dt_best
```




    GradientBoostingClassifier(max_depth=2, min_samples_leaf=5, n_estimators=20)




```python
y_pred = grid_search.predict(x_test)
print("accuracy", metrics.accuracy_score(y_test, y_pred))
```

    accuracy 0.9799846035411856
    


```python
print('Model accuracy score: {0:0.4f}'. format(accuracy_score(y_test, y_pred)))
```

    Model accuracy score: 0.9800
    


```python
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
             red       0.97      0.94      0.96       309
           white       0.98      0.99      0.99       990
    
        accuracy                           0.98      1299
       macro avg       0.98      0.97      0.97      1299
    weighted avg       0.98      0.98      0.98      1299
    
    


```python
##Preparing Data for MLP Model

def create_dummies(df, column_name):
    dummies = pd.get_dummies(df[column_name],prefix=column_name)
    df = pd.concat([df, dummies],axis=1)
    return df
data = create_dummies(df,"wine")
```


```python
##Standardising the Data

unscaled_feature = x_train
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
```


```python
x_train_array = sc.fit_transform(x_train.values)
x_train = pd.DataFrame(x_train_array, index = x_train.index, columns = x_train.columns)
x_test_array = sc.transform(x_test.values)
x_test = pd.DataFrame(x_test_array, index = x_test.index, columns = x_test.columns)
```


```python
mlp = MLPClassifier(100, solver= 'sgd', learning_rate_init=0.01, max_iter = 10000)
mlp.fit(x_train, y_train)
mlp.score(x_test, y_test)
```




    0.9953810623556582




```python
y_pred = mlp.predict(x_test)
y_t_pred = mlp.predict(x_train)
```


```python
train_acc = []
test_acc = []
train_acc.append(metrics.accuracy_score(y_train, y_t_pred))
test_acc.append(metrics.accuracy_score(y_test, y_pred))
print(train_acc)
test_acc
```

    [0.9961501443695862]
    




    [0.9953810623556582]




```python
from sklearn.neural_network import MLPClassifier
mlp = MLPClassifier(100, solver= 'sgd', learning_rate_init=0.01, max_iter = 15000)
mlp.fit(x_train, y_train)
mlp.score(x_test, y_test)
```




    0.9953810623556582




```python
print('Model accuracy score: {0:0.4f}'. format(accuracy_score(y_test, y_pred)))
```

    Model accuracy score: 0.9954
    


```python
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
             red       0.99      0.99      0.99       309
           white       1.00      1.00      1.00       990
    
        accuracy                           1.00      1299
       macro avg       0.99      0.99      0.99      1299
    weighted avg       1.00      1.00      1.00      1299
    
    


```python
#Neural Network with Adam
mlp = MLPClassifier(50, solver='adam', learning_rate_init=0.01, max_iter=10000)
mlp.fit(x_train, y_train)
mlp.score(x_test, y_test)
```




    0.9946112394149346




```python
print('Model accuracy score: {0:0.4f}'. format(accuracy_score(y_test, y_pred)))
```

    Model accuracy score: 0.9954
    


```python
print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
             red       0.99      0.99      0.99       309
           white       1.00      1.00      1.00       990
    
        accuracy                           1.00      1299
       macro avg       0.99      0.99      0.99      1299
    weighted avg       1.00      1.00      1.00      1299
    
    
